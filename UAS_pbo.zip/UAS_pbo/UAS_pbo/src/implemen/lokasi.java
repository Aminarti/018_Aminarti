
package implemen;

interface alamat{
    public String cabang();
}
public class lokasi implements alamat {
    

    public String cabang(){
        return"L4 Desa Kerta Buana";
    }
        
}
